

import Foundation

class FurnitureViewModel: ObservableObject {
    @Published var selectedFurniture: String = ""
}
